
/**
* @file main.c
* @brief Main of Enigme.
* @author DiverCity
* @version 0.1
* @date May 06, 2023
*
* mainc file for program enigme
*
*/

#include <stdio.h>
#include <stdlib.h>
#include "enigme.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <time.h>
#include <SDL/SDL_ttf.h>
void main()
{
enigme e ;
menigme (&e);
SDL_Quit();
}


