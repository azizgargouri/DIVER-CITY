#include "function.h"


int main()
{
	SDL_Surface *screen;
	backg back,back2;
	texte texte;
	int T=0;
	Mix_Music *music;
	SDL_Event event;
	int i=1,direction,direction2;
	int loop = 1;
	scoreinfo tab[100];
	btn b;
	
	
   
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) == -1)
	{
		printf("Could not initialize SDL:  %s.\n",SDL_GetError());
		return -1;
	}

	screen = SDL_SetVideoMode(SCREEN_W, SCREEN_H, 32, SDL_SWSURFACE|SDL_DOUBLEBUF);
	SDL_WM_SetCaption("projet 1A36", NULL);
	
	
	initbackg(&back);
	initbackg2(&back2);
	initialiser_audiobref(music);
	TTF_Init();
	init_btn(&b);
	initialiser_texte(&texte);
	while (loop)
	{
		
				
		SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
		
		afficher(back,screen);
		afficher(back2,screen);
		//animate_back(&back,screen);
		
		display_btn(b,screen);

		while(SDL_PollEvent(&event))
		{
			switch(event.type) 
			{
		 		case SDL_QUIT:
		 		loop = 0;
		 		break;
		 		case SDL_KEYDOWN:
		 		switch (event.key.keysym.sym)
		 		{
		 		case SDLK_LEFT:
		 		direction=1;
		 		direction2=0;
		 		break; 
		 		case SDLK_DOWN:
		 		direction=2;
		 		direction2=0;
		 		break;
		 		case SDLK_RIGHT:
		 		direction=3;
		 		direction2=0;
		 		break;
		 		case SDLK_UP:
		 		direction=5;
		 		direction2=0;
		 		break;
		 		
		 		
		 		case SDLK_s:
		 		direction2=1;
		 		direction=0;
		 		break; 
		 		case SDLK_d:
		 		direction2=2;
		 		direction=0;
		 		break;
		 		case SDLK_f:
		 		direction2=3;
		 		direction=0;
		 		break;
		 		case SDLK_e:
		 		direction2=5;
		 		direction=0;
		 		break;
		 		
		 		}
		 		case SDL_MOUSEBUTTONDOWN:
            if (event.motion.x >= b.posButton.x && event.motion.x <= b.posButton.x + b.posButton.w && event.motion.y >= b.posButton.y && event.motion.y <= b.posButton.y + b.posButton.h)
            {
                bestScore("scores.txt", tab,screen);
                showBestScore(tab, screen);
            }
            break;
		 		break;
		 	}
		 	scrolling (&back2, direction2 );
		 	scrolling (&back, direction );
		 }
		 SDL_Flip(screen);
	}
	return 0;
}
	
	
