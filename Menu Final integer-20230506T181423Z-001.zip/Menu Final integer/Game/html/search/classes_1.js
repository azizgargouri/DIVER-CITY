var searchData=
[
  ['texte_3',['texte',['../structtexte.html',1,'']]]
];
