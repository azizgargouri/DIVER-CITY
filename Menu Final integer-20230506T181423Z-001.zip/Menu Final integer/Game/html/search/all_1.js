var searchData=
[
  ['texte_1',['texte',['../structtexte.html',1,'']]]
];
